package imgui;

import imgui.binding.ImGuiStruct;
import imgui.callback.ImStrConsumer;
import imgui.callback.ImStrSupplier;
import imgui.internal.ImGuiContext;

/**
 * Communicate most settings and inputs/outputs to Dear ImGui using this structure.
 * Access via ImGui::GetIO(). Read 'Programmer guide' section in .cpp file for general usage.
 */
public final class ImGuiIO extends ImGuiStruct {
    public ImGuiIO(final long ptr) {
        super(ptr);
    }

    /*JNI
        #include "_common.h"
        #define THIS ((ImGuiIO*)STRUCT_PTR)
     */

    //------------------------------------------------------------------
    // Configuration (fill once)
    //------------------------------------------------------------------

    /**
     * See ImGuiConfigFlags enum. Set by user/application. Gamepad/keyboard navigation options, etc.
     */
    public int getConfigFlags() {
        return nGetConfigFlags();
    }

    /**
     * See ImGuiConfigFlags enum. Set by user/application. Gamepad/keyboard navigation options, etc.
     */
    public void setConfigFlags(final int value) {
        nSetConfigFlags(value);
    }

    /**
     * See ImGuiConfigFlags enum. Set by user/application. Gamepad/keyboard navigation options, etc.
     */
    public void addConfigFlags(final int flags) {
        setConfigFlags(getConfigFlags() | flags);
    }

    /**
     * See ImGuiConfigFlags enum. Set by user/application. Gamepad/keyboard navigation options, etc.
     */
    public void removeConfigFlags(final int flags) {
        setConfigFlags(getConfigFlags() & ~(flags));
    }

    /**
     * See ImGuiConfigFlags enum. Set by user/application. Gamepad/keyboard navigation options, etc.
     */
    public boolean hasConfigFlags(final int flags) {
        return (getConfigFlags() & flags) != 0;
    }

    private native int nGetConfigFlags(); /*
        return THIS->ConfigFlags;
    */

    private native void nSetConfigFlags(int value); /*
        THIS->ConfigFlags = value;
    */

    /**
     * See ImGuiBackendFlags enum. Set by backend to communicate features supported by the backend.
     */
    public int getBackendFlags() {
        return nGetBackendFlags();
    }

    /**
     * See ImGuiBackendFlags enum. Set by backend to communicate features supported by the backend.
     */
    public void setBackendFlags(final int value) {
        nSetBackendFlags(value);
    }

    /**
     * See ImGuiBackendFlags enum. Set by backend to communicate features supported by the backend.
     */
    public void addBackendFlags(final int flags) {
        setBackendFlags(getBackendFlags() | flags);
    }

    /**
     * See ImGuiBackendFlags enum. Set by backend to communicate features supported by the backend.
     */
    public void removeBackendFlags(final int flags) {
        setBackendFlags(getBackendFlags() & ~(flags));
    }

    /**
     * See ImGuiBackendFlags enum. Set by backend to communicate features supported by the backend.
     */
    public boolean hasBackendFlags(final int flags) {
        return (getBackendFlags() & flags) != 0;
    }

    private native int nGetBackendFlags(); /*
        return THIS->BackendFlags;
    */

    private native void nSetBackendFlags(int value); /*
        THIS->BackendFlags = value;
    */

    /**
     * Main display size, in pixels (generally == {@code GetMainViewport()->Size}). May change every frame.
     */
    public ImVec2 getDisplaySize() {
        final ImVec2 dst = new ImVec2();
        nGetDisplaySize(dst);
        return dst;
    }

    /**
     * Main display size, in pixels (generally == {@code GetMainViewport()->Size}). May change every frame.
     */
    public float getDisplaySizeX() {
        return nGetDisplaySizeX();
    }

    /**
     * Main display size, in pixels (generally == {@code GetMainViewport()->Size}). May change every frame.
     */
    public float getDisplaySizeY() {
        return nGetDisplaySizeY();
    }

    /**
     * Main display size, in pixels (generally == {@code GetMainViewport()->Size}). May change every frame.
     */
    public void getDisplaySize(final ImVec2 dst) {
        nGetDisplaySize(dst);
    }

    /**
     * Main display size, in pixels (generally == {@code GetMainViewport()->Size}). May change every frame.
     */
    public void setDisplaySize(final ImVec2 value) {
        nSetDisplaySize(value.x, value.y);
    }

    /**
     * Main display size, in pixels (generally == {@code GetMainViewport()->Size}). May change every frame.
     */
    public void setDisplaySize(final float valueX, final float valueY) {
        nSetDisplaySize(valueX, valueY);
    }

    private native void nGetDisplaySize(ImVec2 dst); /*
        Jni::ImVec2Cpy(env, THIS->DisplaySize, dst);
    */

    private native float nGetDisplaySizeX(); /*
        return THIS->DisplaySize.x;
    */

    private native float nGetDisplaySizeY(); /*
        return THIS->DisplaySize.y;
    */

    private native void nSetDisplaySize(float valueX, float valueY); /*MANUAL
        ImVec2 value = ImVec2(valueX, valueY);
        THIS->DisplaySize = value;
    */

    /**
     * Time elapsed since last frame, in seconds. May change every frame.
     */
    public float getDeltaTime() {
        return nGetDeltaTime();
    }

    /**
     * Time elapsed since last frame, in seconds. May change every frame.
     */
    public void setDeltaTime(final float value) {
        nSetDeltaTime(value);
    }

    private native float nGetDeltaTime(); /*
        return THIS->DeltaTime;
    */

    private native void nSetDeltaTime(float value); /*
        THIS->DeltaTime = value;
    */

    /**
     * Minimum time between saving positions/sizes to .ini file, in seconds.
     */
    public float getIniSavingRate() {
        return nGetIniSavingRate();
    }

    /**
     * Minimum time between saving positions/sizes to .ini file, in seconds.
     */
    public void setIniSavingRate(final float value) {
        nSetIniSavingRate(value);
    }

    private native float nGetIniSavingRate(); /*
        return THIS->IniSavingRate;
    */

    private native void nSetIniSavingRate(float value); /*
        THIS->IniSavingRate = value;
    */

    /**
     * Path to .ini file. Set NULL to disable automatic .ini loading/saving, if e.g. you want to manually load/save from memory.
     */
    public String getIniFilename() {
        return nGetIniFilename();
    }

    /**
     * Path to .ini file. Set NULL to disable automatic .ini loading/saving, if e.g. you want to manually load/save from memory.
     */
    public void setIniFilename(final String value) {
        nSetIniFilename(value);
    }

    private native String nGetIniFilename(); /*
        return env->NewStringUTF(THIS->IniFilename);
    */

    private native void nSetIniFilename(String value); /*MANUAL
        auto value = obj_value == NULL ? NULL : (char*)env->GetStringUTFChars(obj_value, JNI_FALSE);
        SET_STRING_FIELD(THIS->IniFilename, value);
        if (value != NULL) env->ReleaseStringUTFChars(obj_value, value);
    */

    /**
     * Path to .log file (default parameter to ImGui::LogToFile when no file is specified).
     */
    public String getLogFilename() {
        return nGetLogFilename();
    }

    /**
     * Path to .log file (default parameter to ImGui::LogToFile when no file is specified).
     */
    public void setLogFilename(final String value) {
        nSetLogFilename(value);
    }

    private native String nGetLogFilename(); /*
        return env->NewStringUTF(THIS->LogFilename);
    */

    private native void nSetLogFilename(String value); /*MANUAL
        auto value = obj_value == NULL ? NULL : (char*)env->GetStringUTFChars(obj_value, JNI_FALSE);
        SET_STRING_FIELD(THIS->LogFilename, value);
        if (value != NULL) env->ReleaseStringUTFChars(obj_value, value);
    */

    private static final ImFontAtlas _GETFONTS_1 = new ImFontAtlas(0);

    /**
     * Font atlas: load, rasterize and pack one or more fonts into a single texture.
     */
    public ImFontAtlas getFonts() {
        _GETFONTS_1.ptr = nGetFonts();
        return _GETFONTS_1;
    }

    /**
     * Font atlas: load, rasterize and pack one or more fonts into a single texture.
     */
    public void setFonts(final ImFontAtlas value) {
        nSetFonts(value.ptr);
    }

    private native long nGetFonts(); /*
        return (uintptr_t)THIS->Fonts;
    */

    private native void nSetFonts(long value); /*
        THIS->Fonts = reinterpret_cast<ImFontAtlas*>(value);
    */

    /**
     * Global scale all fonts
     */
    public float getFontGlobalScale() {
        return nGetFontGlobalScale();
    }

    /**
     * Global scale all fonts
     */
    public void setFontGlobalScale(final float value) {
        nSetFontGlobalScale(value);
    }

    private native float nGetFontGlobalScale(); /*
        return THIS->FontGlobalScale;
    */

    private native void nSetFontGlobalScale(float value); /*
        THIS->FontGlobalScale = value;
    */

    /**
     * Allow user scaling text of individual window with CTRL+Wheel.
     */
    public boolean getFontAllowUserScaling() {
        return nGetFontAllowUserScaling();
    }

    /**
     * Allow user scaling text of individual window with CTRL+Wheel.
     */
    public void setFontAllowUserScaling(final boolean value) {
        nSetFontAllowUserScaling(value);
    }

    private native boolean nGetFontAllowUserScaling(); /*
        return THIS->FontAllowUserScaling;
    */

    private native void nSetFontAllowUserScaling(boolean value); /*
        THIS->FontAllowUserScaling = value;
    */

    /**
     * Font to use on NewFrame(). Use NULL to uses Fonts{@code ->}Fonts[0].
     */
    public ImFont getFontDefault() {
        return new ImFont(nGetFontDefault());
    }

    /**
     * Font to use on NewFrame(). Use NULL to uses Fonts{@code ->}Fonts[0].
     */
    public void setFontDefault(final ImFont value) {
        nSetFontDefault(value.ptr);
    }

    private native long nGetFontDefault(); /*
        return (uintptr_t)THIS->FontDefault;
    */

    private native void nSetFontDefault(long value); /*
        THIS->FontDefault = reinterpret_cast<ImFont*>(value);
    */

    /**
     * For retina display or other situations where window coordinates are different from framebuffer coordinates. This generally ends up in ImDrawData::FramebufferScale.
     */
    public ImVec2 getDisplayFramebufferScale() {
        final ImVec2 dst = new ImVec2();
        nGetDisplayFramebufferScale(dst);
        return dst;
    }

    /**
     * For retina display or other situations where window coordinates are different from framebuffer coordinates. This generally ends up in ImDrawData::FramebufferScale.
     */
    public float getDisplayFramebufferScaleX() {
        return nGetDisplayFramebufferScaleX();
    }

    /**
     * For retina display or other situations where window coordinates are different from framebuffer coordinates. This generally ends up in ImDrawData::FramebufferScale.
     */
    public float getDisplayFramebufferScaleY() {
        return nGetDisplayFramebufferScaleY();
    }

    /**
     * For retina display or other situations where window coordinates are different from framebuffer coordinates. This generally ends up in ImDrawData::FramebufferScale.
     */
    public void getDisplayFramebufferScale(final ImVec2 dst) {
        nGetDisplayFramebufferScale(dst);
    }

    /**
     * For retina display or other situations where window coordinates are different from framebuffer coordinates. This generally ends up in ImDrawData::FramebufferScale.
     */
    public void setDisplayFramebufferScale(final ImVec2 value) {
        nSetDisplayFramebufferScale(value.x, value.y);
    }

    /**
     * For retina display or other situations where window coordinates are different from framebuffer coordinates. This generally ends up in ImDrawData::FramebufferScale.
     */
    public void setDisplayFramebufferScale(final float valueX, final float valueY) {
        nSetDisplayFramebufferScale(valueX, valueY);
    }

    private native void nGetDisplayFramebufferScale(ImVec2 dst); /*
        Jni::ImVec2Cpy(env, THIS->DisplayFramebufferScale, dst);
    */

    private native float nGetDisplayFramebufferScaleX(); /*
        return THIS->DisplayFramebufferScale.x;
    */

    private native float nGetDisplayFramebufferScaleY(); /*
        return THIS->DisplayFramebufferScale.y;
    */

    private native void nSetDisplayFramebufferScale(float valueX, float valueY); /*MANUAL
        ImVec2 value = ImVec2(valueX, valueY);
        THIS->DisplayFramebufferScale = value;
    */

    // Docking options (when ImGuiConfigFlags_DockingEnable is set)

    /**
     * Simplified docking mode: disable window splitting, so docking is limited to merging multiple windows together into tab-bars.
     */
    public boolean getConfigDockingNoSplit() {
        return nGetConfigDockingNoSplit();
    }

    /**
     * Simplified docking mode: disable window splitting, so docking is limited to merging multiple windows together into tab-bars.
     */
    public void setConfigDockingNoSplit(final boolean value) {
        nSetConfigDockingNoSplit(value);
    }

    private native boolean nGetConfigDockingNoSplit(); /*
        return THIS->ConfigDockingNoSplit;
    */

    private native void nSetConfigDockingNoSplit(boolean value); /*
        THIS->ConfigDockingNoSplit = value;
    */

    /**
     * Simplified docking mode: disable window merging into the same tab-bar, so docking is limited to splitting windows.
     * (new in imgui 1.92)
     */
    public boolean getConfigDockingNoDockingOver() {
        return nGetConfigDockingNoDockingOver();
    }

    /**
     * Simplified docking mode: disable window merging into the same tab-bar, so docking is limited to splitting windows.
     * (new in imgui 1.92)
     */
    public void setConfigDockingNoDockingOver(final boolean value) {
        nSetConfigDockingNoDockingOver(value);
    }

    private native boolean nGetConfigDockingNoDockingOver(); /*
        return THIS->ConfigDockingNoDockingOver;
    */

    private native void nSetConfigDockingNoDockingOver(boolean value); /*
        THIS->ConfigDockingNoDockingOver = value;
    */

    /**
     * Enable docking with holding Shift key (reduce visual noise, allows dropping in wider space)
     */
    public boolean getConfigDockingWithShift() {
        return nGetConfigDockingWithShift();
    }

    /**
     * Enable docking with holding Shift key (reduce visual noise, allows dropping in wider space)
     */
    public void setConfigDockingWithShift(final boolean value) {
        nSetConfigDockingWithShift(value);
    }

    private native boolean nGetConfigDockingWithShift(); /*
        return THIS->ConfigDockingWithShift;
    */

    private native void nSetConfigDockingWithShift(boolean value); /*
        THIS->ConfigDockingWithShift = value;
    */

    public boolean getConfigDockingAlwaysTabBar() {
        return nGetConfigDockingAlwaysTabBar();
    }

    public void setConfigDockingAlwaysTabBar(final boolean value) {
        nSetConfigDockingAlwaysTabBar(value);
    }

    private native boolean nGetConfigDockingAlwaysTabBar(); /*
        return THIS->ConfigDockingAlwaysTabBar;
    */

    private native void nSetConfigDockingAlwaysTabBar(boolean value); /*
        THIS->ConfigDockingAlwaysTabBar = value;
    */

    /**
     * Make window or viewport transparent when docking and only display docking boxes on the target viewport. Useful if rendering of multiple viewport cannot be synced. Best used with ConfigViewportsNoAutoMerge.
     */
    public boolean getConfigDockingTransparentPayload() {
        return nGetConfigDockingTransparentPayload();
    }

    /**
     * Make window or viewport transparent when docking and only display docking boxes on the target viewport. Useful if rendering of multiple viewport cannot be synced. Best used with ConfigViewportsNoAutoMerge.
     */
    public void setConfigDockingTransparentPayload(final boolean value) {
        nSetConfigDockingTransparentPayload(value);
    }

    private native boolean nGetConfigDockingTransparentPayload(); /*
        return THIS->ConfigDockingTransparentPayload;
    */

    private native void nSetConfigDockingTransparentPayload(boolean value); /*
        THIS->ConfigDockingTransparentPayload = value;
    */

    // Viewport options (when ImGuiConfigFlags_ViewportsEnable is set)

    /**
     * Set to make all floating imgui windows always create their own viewport. Otherwise, they are merged into the main host viewports when overlapping it. May also set ImGuiViewportFlags_NoAutoMerge on individual viewport.
     */
    public boolean getConfigViewportsNoAutoMerge() {
        return nGetConfigViewportsNoAutoMerge();
    }

    /**
     * Set to make all floating imgui windows always create their own viewport. Otherwise, they are merged into the main host viewports when overlapping it. May also set ImGuiViewportFlags_NoAutoMerge on individual viewport.
     */
    public void setConfigViewportsNoAutoMerge(final boolean value) {
        nSetConfigViewportsNoAutoMerge(value);
    }

    private native boolean nGetConfigViewportsNoAutoMerge(); /*
        return THIS->ConfigViewportsNoAutoMerge;
    */

    private native void nSetConfigViewportsNoAutoMerge(boolean value); /*
        THIS->ConfigViewportsNoAutoMerge = value;
    */

    /**
     * Disable default OS task bar icon flag for secondary viewports. When a viewport doesn't want a task bar icon, ImGuiViewportFlags_NoTaskBarIcon will be set on it.
     */
    public boolean getConfigViewportsNoTaskBarIcon() {
        return nGetConfigViewportsNoTaskBarIcon();
    }

    /**
     * Disable default OS task bar icon flag for secondary viewports. When a viewport doesn't want a task bar icon, ImGuiViewportFlags_NoTaskBarIcon will be set on it.
     */
    public void setConfigViewportsNoTaskBarIcon(final boolean value) {
        nSetConfigViewportsNoTaskBarIcon(value);
    }

    private native boolean nGetConfigViewportsNoTaskBarIcon(); /*
        return THIS->ConfigViewportsNoTaskBarIcon;
    */

    private native void nSetConfigViewportsNoTaskBarIcon(boolean value); /*
        THIS->ConfigViewportsNoTaskBarIcon = value;
    */

    /**
     * Disable default OS window decoration flag for secondary viewports. When a viewport doesn't want window decorations, ImGuiViewportFlags_NoDecoration will be set on it. Enabling decoration can create subsequent issues at OS levels (e.g. minimum window size).
     */
    public boolean getConfigViewportsNoDecoration() {
        return nGetConfigViewportsNoDecoration();
    }

    /**
     * Disable default OS window decoration flag for secondary viewports. When a viewport doesn't want window decorations, ImGuiViewportFlags_NoDecoration will be set on it. Enabling decoration can create subsequent issues at OS levels (e.g. minimum window size).
     */
    public void setConfigViewportsNoDecoration(final boolean value) {
        nSetConfigViewportsNoDecoration(value);
    }

    private native boolean nGetConfigViewportsNoDecoration(); /*
        return THIS->ConfigViewportsNoDecoration;
    */

    private native void nSetConfigViewportsNoDecoration(boolean value); /*
        THIS->ConfigViewportsNoDecoration = value;
    */

    /**
     * Disable default OS parenting to main viewport for secondary viewports. By default, viewports are marked with ParentViewportId = {@code <main_viewport>}, expecting the platform backend to setup a parent/child relationship between the OS windows (some backend may ignore this). Set to true if you want the default to be 0, then all viewports will be top-level OS windows.
     */
    public boolean getConfigViewportsNoDefaultParent() {
        return nGetConfigViewportsNoDefaultParent();
    }

    /**
     * Disable default OS parenting to main viewport for secondary viewports. By default, viewports are marked with ParentViewportId = {@code <main_viewport>}, expecting the platform backend to setup a parent/child relationship between the OS windows (some backend may ignore this). Set to true if you want the default to be 0, then all viewports will be top-level OS windows.
     */
    public void setConfigViewportsNoDefaultParent(final boolean value) {
        nSetConfigViewportsNoDefaultParent(value);
    }

    private native boolean nGetConfigViewportsNoDefaultParent(); /*
        return THIS->ConfigViewportsNoDefaultParent;
    */

    private native void nSetConfigViewportsNoDefaultParent(boolean value); /*
        THIS->ConfigViewportsNoDefaultParent = value;
    */

    /**
     * [EXPERIMENTAL] Automatically overwrite {@code style.FontScaleDpi} when monitor DPI changes.
     * Scales fonts but NOT sizes/padding (for now). Docking branch only. (since imgui 1.92)
     */
    public boolean getConfigDpiScaleFonts() {
        return nGetConfigDpiScaleFonts();
    }

    /**
     * [EXPERIMENTAL] Automatically overwrite {@code style.FontScaleDpi} when monitor DPI changes.
     * Scales fonts but NOT sizes/padding (for now). Docking branch only. (since imgui 1.92)
     */
    public void setConfigDpiScaleFonts(final boolean value) {
        nSetConfigDpiScaleFonts(value);
    }

    private native boolean nGetConfigDpiScaleFonts(); /*
        return THIS->ConfigDpiScaleFonts;
    */

    private native void nSetConfigDpiScaleFonts(boolean value); /*
        THIS->ConfigDpiScaleFonts = value;
    */

    /**
     * [EXPERIMENTAL] Scale Dear ImGui and platform windows when monitor DPI changes. Docking branch only. (since imgui 1.92)
     */
    public boolean getConfigDpiScaleViewports() {
        return nGetConfigDpiScaleViewports();
    }

    /**
     * [EXPERIMENTAL] Scale Dear ImGui and platform windows when monitor DPI changes. Docking branch only. (since imgui 1.92)
     */
    public void setConfigDpiScaleViewports(final boolean value) {
        nSetConfigDpiScaleViewports(value);
    }

    private native boolean nGetConfigDpiScaleViewports(); /*
        return THIS->ConfigDpiScaleViewports;
    */

    private native void nSetConfigDpiScaleViewports(boolean value); /*
        THIS->ConfigDpiScaleViewports = value;
    */

    /**
     * Enable error recovery support. Some errors won't be detected and lead to direct crashes if recovery is disabled. (since imgui 1.91.6)
     */
    public boolean getConfigErrorRecovery() {
        return nGetConfigErrorRecovery();
    }

    /**
     * Enable error recovery support. Some errors won't be detected and lead to direct crashes if recovery is disabled. (since imgui 1.91.6)
     */
    public void setConfigErrorRecovery(final boolean value) {
        nSetConfigErrorRecovery(value);
    }

    private native boolean nGetConfigErrorRecovery(); /*
        return THIS->ConfigErrorRecovery;
    */

    private native void nSetConfigErrorRecovery(boolean value); /*
        THIS->ConfigErrorRecovery = value;
    */

    /**
     * Enable asserts on recoverable errors. By default calls IM_ASSERT() when returning from a failing IM_ASSERT_USER_ERROR(). (since imgui 1.91.6)
     */
    public boolean getConfigErrorRecoveryEnableAssert() {
        return nGetConfigErrorRecoveryEnableAssert();
    }

    /**
     * Enable asserts on recoverable errors. By default calls IM_ASSERT() when returning from a failing IM_ASSERT_USER_ERROR(). (since imgui 1.91.6)
     */
    public void setConfigErrorRecoveryEnableAssert(final boolean value) {
        nSetConfigErrorRecoveryEnableAssert(value);
    }

    private native boolean nGetConfigErrorRecoveryEnableAssert(); /*
        return THIS->ConfigErrorRecoveryEnableAssert;
    */

    private native void nSetConfigErrorRecoveryEnableAssert(boolean value); /*
        THIS->ConfigErrorRecoveryEnableAssert = value;
    */

    /**
     * Enable debug log output on recoverable errors. (since imgui 1.91.6)
     */
    public boolean getConfigErrorRecoveryEnableDebugLog() {
        return nGetConfigErrorRecoveryEnableDebugLog();
    }

    /**
     * Enable debug log output on recoverable errors. (since imgui 1.91.6)
     */
    public void setConfigErrorRecoveryEnableDebugLog(final boolean value) {
        nSetConfigErrorRecoveryEnableDebugLog(value);
    }

    private native boolean nGetConfigErrorRecoveryEnableDebugLog(); /*
        return THIS->ConfigErrorRecoveryEnableDebugLog;
    */

    private native void nSetConfigErrorRecoveryEnableDebugLog(boolean value); /*
        THIS->ConfigErrorRecoveryEnableDebugLog = value;
    */

    /**
     * Enable tooltip on recoverable errors. The tooltip includes a way to enable asserts if they were disabled. (since imgui 1.91.6)
     */
    public boolean getConfigErrorRecoveryEnableTooltip() {
        return nGetConfigErrorRecoveryEnableTooltip();
    }

    /**
     * Enable tooltip on recoverable errors. The tooltip includes a way to enable asserts if they were disabled. (since imgui 1.91.6)
     */
    public void setConfigErrorRecoveryEnableTooltip(final boolean value) {
        nSetConfigErrorRecoveryEnableTooltip(value);
    }

    private native boolean nGetConfigErrorRecoveryEnableTooltip(); /*
        return THIS->ConfigErrorRecoveryEnableTooltip;
    */

    private native void nSetConfigErrorRecoveryEnableTooltip(boolean value); /*
        THIS->ConfigErrorRecoveryEnableTooltip = value;
    */

    /**
     * Highlight and show an error message popup when multiple items have conflicting identifiers. (since imgui 1.91.0)
     */
    public boolean getConfigDebugHighlightIdConflicts() {
        return nGetConfigDebugHighlightIdConflicts();
    }

    /**
     * Highlight and show an error message popup when multiple items have conflicting identifiers. (since imgui 1.91.0)
     */
    public void setConfigDebugHighlightIdConflicts(final boolean value) {
        nSetConfigDebugHighlightIdConflicts(value);
    }

    private native boolean nGetConfigDebugHighlightIdConflicts(); /*
        return THIS->ConfigDebugHighlightIdConflicts;
    */

    private native void nSetConfigDebugHighlightIdConflicts(boolean value); /*
        THIS->ConfigDebugHighlightIdConflicts = value;
    */

    // Miscellaneous options

    /**
     * Request ImGui to draw a mouse cursor for you (if you are on a platform without a mouse cursor).
     * Cannot be easily renamed to 'io.ConfigXXX' because this is frequently used by backend implementations.
     */
    public boolean getMouseDrawCursor() {
        return nGetMouseDrawCursor();
    }

    /**
     * Request ImGui to draw a mouse cursor for you (if you are on a platform without a mouse cursor).
     * Cannot be easily renamed to 'io.ConfigXXX' because this is frequently used by backend implementations.
     */
    public void setMouseDrawCursor(final boolean value) {
        nSetMouseDrawCursor(value);
    }

    private native boolean nGetMouseDrawCursor(); /*
        return THIS->MouseDrawCursor;
    */

    private native void nSetMouseDrawCursor(boolean value); /*
        THIS->MouseDrawCursor = value;
    */

    /**
     * OS X style: Text editing cursor movement using Alt instead of Ctrl, Shortcuts using Cmd/Super instead of Ctrl,
     * Line/Text Start and End using Cmd+Arrows instead of Home/End, Double click selects by word instead of selecting whole text,
     * Multi-selection in lists uses Cmd/Super instead of Ctrl
     */
    public boolean getConfigMacOSXBehaviors() {
        return nGetConfigMacOSXBehaviors();
    }

    /**
     * OS X style: Text editing cursor movement using Alt instead of Ctrl, Shortcuts using Cmd/Super instead of Ctrl,
     * Line/Text Start and End using Cmd+Arrows instead of Home/End, Double click selects by word instead of selecting whole text,
     * Multi-selection in lists uses Cmd/Super instead of Ctrl
     */
    public void setConfigMacOSXBehaviors(final boolean value) {
        nSetConfigMacOSXBehaviors(value);
    }

    private native boolean nGetConfigMacOSXBehaviors(); /*
        return THIS->ConfigMacOSXBehaviors;
    */

    private native void nSetConfigMacOSXBehaviors(boolean value); /*
        THIS->ConfigMacOSXBehaviors = value;
    */

    /**
     * Enable input queue trickling: some types of events submitted during the same frame (e.g. button down + up) will be spread over multiple frames, improving interactions with low framerates.
     */
    public boolean getConfigInputTrickleEventQueue() {
        return nGetConfigInputTrickleEventQueue();
    }

    /**
     * Enable input queue trickling: some types of events submitted during the same frame (e.g. button down + up) will be spread over multiple frames, improving interactions with low framerates.
     */
    public void setConfigInputTrickleEventQueue(final boolean value) {
        nSetConfigInputTrickleEventQueue(value);
    }

    private native boolean nGetConfigInputTrickleEventQueue(); /*
        return THIS->ConfigInputTrickleEventQueue;
    */

    private native void nSetConfigInputTrickleEventQueue(boolean value); /*
        THIS->ConfigInputTrickleEventQueue = value;
    */

    /**
     * Set to false to disable blinking cursor, for users who consider it distracting.
     */
    public boolean getConfigInputTextCursorBlink() {
        return nGetConfigInputTextCursorBlink();
    }

    /**
     * Set to false to disable blinking cursor, for users who consider it distracting.
     */
    public void setConfigInputTextCursorBlink(final boolean value) {
        nSetConfigInputTextCursorBlink(value);
    }

    private native boolean nGetConfigInputTextCursorBlink(); /*
        return THIS->ConfigInputTextCursorBlink;
    */

    private native void nSetConfigInputTextCursorBlink(boolean value); /*
        THIS->ConfigInputTextCursorBlink = value;
    */

    /**
     * [BETA] Pressing Enter will keep item active and select contents (single-line only).
     */
    public boolean getConfigInputTextEnterKeepActive() {
        return nGetConfigInputTextEnterKeepActive();
    }

    /**
     * [BETA] Pressing Enter will keep item active and select contents (single-line only).
     */
    public void setConfigInputTextEnterKeepActive(final boolean value) {
        nSetConfigInputTextEnterKeepActive(value);
    }

    private native boolean nGetConfigInputTextEnterKeepActive(); /*
        return THIS->ConfigInputTextEnterKeepActive;
    */

    private native void nSetConfigInputTextEnterKeepActive(boolean value); /*
        THIS->ConfigInputTextEnterKeepActive = value;
    */

    /**
     * [BETA] Enable turning DragXXX widgets into text input with a simple mouse click-release (without moving). Not desirable on devices without a keyboard.
     */
    public boolean getConfigDragClickToInputText() {
        return nGetConfigDragClickToInputText();
    }

    /**
     * [BETA] Enable turning DragXXX widgets into text input with a simple mouse click-release (without moving). Not desirable on devices without a keyboard.
     */
    public void setConfigDragClickToInputText(final boolean value) {
        nSetConfigDragClickToInputText(value);
    }

    private native boolean nGetConfigDragClickToInputText(); /*
        return THIS->ConfigDragClickToInputText;
    */

    private native void nSetConfigDragClickToInputText(boolean value); /*
        THIS->ConfigDragClickToInputText = value;
    */

    /**
     * Enable resizing of windows from their edges and from the lower-left corner.
     * This requires (io.BackendFlags {@code &} ImGuiBackendFlags_HasMouseCursors) because it needs mouse cursor feedback.
     * (This used to be a per-window ImGuiWindowFlags_ResizeFromAnySide flag)
     */
    public boolean getConfigWindowsResizeFromEdges() {
        return nGetConfigWindowsResizeFromEdges();
    }

    /**
     * Enable resizing of windows from their edges and from the lower-left corner.
     * This requires (io.BackendFlags {@code &} ImGuiBackendFlags_HasMouseCursors) because it needs mouse cursor feedback.
     * (This used to be a per-window ImGuiWindowFlags_ResizeFromAnySide flag)
     */
    public void setConfigWindowsResizeFromEdges(final boolean value) {
        nSetConfigWindowsResizeFromEdges(value);
    }

    private native boolean nGetConfigWindowsResizeFromEdges(); /*
        return THIS->ConfigWindowsResizeFromEdges;
    */

    private native void nSetConfigWindowsResizeFromEdges(boolean value); /*
        THIS->ConfigWindowsResizeFromEdges = value;
    */

    /**
     * Enable allowing to move windows only when clicking on their title bar. Does not apply to windows without a title bar.
     */
    public boolean getConfigWindowsMoveFromTitleBarOnly() {
        return nGetConfigWindowsMoveFromTitleBarOnly();
    }

    /**
     * Enable allowing to move windows only when clicking on their title bar. Does not apply to windows without a title bar.
     */
    public void setConfigWindowsMoveFromTitleBarOnly(final boolean value) {
        nSetConfigWindowsMoveFromTitleBarOnly(value);
    }

    private native boolean nGetConfigWindowsMoveFromTitleBarOnly(); /*
        return THIS->ConfigWindowsMoveFromTitleBarOnly;
    */

    private native void nSetConfigWindowsMoveFromTitleBarOnly(boolean value); /*
        THIS->ConfigWindowsMoveFromTitleBarOnly = value;
    */

    /**
     * [Timer (in seconds) to free transient windows/tables memory buffers when unused. Set to -1.0f to disable.
     */
    public boolean getConfigMemoryCompactTimer() {
        return nGetConfigMemoryCompactTimer();
    }

    /**
     * [Timer (in seconds) to free transient windows/tables memory buffers when unused. Set to -1.0f to disable.
     */
    public void setConfigMemoryCompactTimer(final boolean value) {
        nSetConfigMemoryCompactTimer(value);
    }

    private native boolean nGetConfigMemoryCompactTimer(); /*
        return THIS->ConfigMemoryCompactTimer;
    */

    private native void nSetConfigMemoryCompactTimer(boolean value); /*
        THIS->ConfigMemoryCompactTimer = value;
    */

    // Inputs Behaviors
    // (other variables, ones which are expected to be tweaked within UI code, are exposed in ImGuiStyle)


    /**
     * Time for a double-click, in seconds.
     */
    public float getMouseDoubleClickTime() {
        return nGetMouseDoubleClickTime();
    }

    /**
     * Time for a double-click, in seconds.
     */
    public void setMouseDoubleClickTime(final float value) {
        nSetMouseDoubleClickTime(value);
    }

    private native float nGetMouseDoubleClickTime(); /*
        return THIS->MouseDoubleClickTime;
    */

    private native void nSetMouseDoubleClickTime(float value); /*
        THIS->MouseDoubleClickTime = value;
    */

    /**
     * Distance threshold to stay in to validate a double-click, in pixels.
     */
    public float getMouseDoubleClickMaxDist() {
        return nGetMouseDoubleClickMaxDist();
    }

    /**
     * Distance threshold to stay in to validate a double-click, in pixels.
     */
    public void setMouseDoubleClickMaxDist(final float value) {
        nSetMouseDoubleClickMaxDist(value);
    }

    private native float nGetMouseDoubleClickMaxDist(); /*
        return THIS->MouseDoubleClickMaxDist;
    */

    private native void nSetMouseDoubleClickMaxDist(float value); /*
        THIS->MouseDoubleClickMaxDist = value;
    */

    /**
     * Distance threshold before considering we are dragging.
     */
    public float getMouseDragThreshold() {
        return nGetMouseDragThreshold();
    }

    /**
     * Distance threshold before considering we are dragging.
     */
    public void setMouseDragThreshold(final float value) {
        nSetMouseDragThreshold(value);
    }

    private native float nGetMouseDragThreshold(); /*
        return THIS->MouseDragThreshold;
    */

    private native void nSetMouseDragThreshold(float value); /*
        THIS->MouseDragThreshold = value;
    */

    /**
     * When holding a key/button, time before it starts repeating, in seconds (for buttons in Repeat mode, etc.).
     */
    public float getKeyRepeatDelay() {
        return nGetKeyRepeatDelay();
    }

    /**
     * When holding a key/button, time before it starts repeating, in seconds (for buttons in Repeat mode, etc.).
     */
    public void setKeyRepeatDelay(final float value) {
        nSetKeyRepeatDelay(value);
    }

    private native float nGetKeyRepeatDelay(); /*
        return THIS->KeyRepeatDelay;
    */

    private native void nSetKeyRepeatDelay(float value); /*
        THIS->KeyRepeatDelay = value;
    */

    /**
     * When holding a key/button, rate at which it repeats, in seconds.
     */
    public float getKeyRepeatRate() {
        return nGetKeyRepeatRate();
    }

    /**
     * When holding a key/button, rate at which it repeats, in seconds.
     */
    public void setKeyRepeatRate(final float value) {
        nSetKeyRepeatRate(value);
    }

    private native float nGetKeyRepeatRate(); /*
        return THIS->KeyRepeatRate;
    */

    private native void nSetKeyRepeatRate(float value); /*
        THIS->KeyRepeatRate = value;
    */

    //------------------------------------------------------------------
    // Debug options
    //------------------------------------------------------------------

    /**
     * Option to enable various debug tools showing buttons that will call the IM_DEBUG_BREAK() macro.
     * - The Item Picker tool will be available regardless of this being enabled, in order to maximize its discoverability.
     * - Requires a debugger being attached, otherwise IM_DEBUG_BREAK() options will appear to crash your application.
     * e.g. io.ConfigDebugIsDebuggerPresent = ::IsDebuggerPresent() on Win32, or refer to ImOsIsDebuggerPresent() imgui_test_engine/imgui_te_utils.cpp for a Unix compatible version).
     */
    public boolean getConfigDebugIsDebuggerPresent() {
        return nGetConfigDebugIsDebuggerPresent();
    }

    /**
     * Option to enable various debug tools showing buttons that will call the IM_DEBUG_BREAK() macro.
     * - The Item Picker tool will be available regardless of this being enabled, in order to maximize its discoverability.
     * - Requires a debugger being attached, otherwise IM_DEBUG_BREAK() options will appear to crash your application.
     * e.g. io.ConfigDebugIsDebuggerPresent = ::IsDebuggerPresent() on Win32, or refer to ImOsIsDebuggerPresent() imgui_test_engine/imgui_te_utils.cpp for a Unix compatible version).
     */
    public void setConfigDebugIsDebuggerPresent(final boolean value) {
        nSetConfigDebugIsDebuggerPresent(value);
    }

    private native boolean nGetConfigDebugIsDebuggerPresent(); /*
        return THIS->ConfigDebugIsDebuggerPresent;
    */

    private native void nSetConfigDebugIsDebuggerPresent(boolean value); /*
        THIS->ConfigDebugIsDebuggerPresent = value;
    */

    /**
     * Tools to test correct Begin/End and BeginChild/EndChild behaviors.
     * Presently Begin()/End() and BeginChild()/EndChild() needs to ALWAYS be called in tandem, regardless of return value of BeginXXX()
     * This is inconsistent with other BeginXXX functions and create confusion for many users.
     * We expect to update the API eventually. In the meanwhile we provide tools to facilitate checking user-code behavior.
     * First-time calls to Begin()/BeginChild() will return false. NEEDS TO BE SET AT APPLICATION BOOT TIME if you don't want to miss windows.
     */
    public boolean getConfigDebugBeginReturnValueOnce() {
        return nGetConfigDebugBeginReturnValueOnce();
    }

    /**
     * Tools to test correct Begin/End and BeginChild/EndChild behaviors.
     * Presently Begin()/End() and BeginChild()/EndChild() needs to ALWAYS be called in tandem, regardless of return value of BeginXXX()
     * This is inconsistent with other BeginXXX functions and create confusion for many users.
     * We expect to update the API eventually. In the meanwhile we provide tools to facilitate checking user-code behavior.
     * First-time calls to Begin()/BeginChild() will return false. NEEDS TO BE SET AT APPLICATION BOOT TIME if you don't want to miss windows.
     */
    public void setConfigDebugBeginReturnValueOnce(final boolean value) {
        nSetConfigDebugBeginReturnValueOnce(value);
    }

    private native boolean nGetConfigDebugBeginReturnValueOnce(); /*
        return THIS->ConfigDebugBeginReturnValueOnce;
    */

    private native void nSetConfigDebugBeginReturnValueOnce(boolean value); /*
        THIS->ConfigDebugBeginReturnValueOnce = value;
    */

    /**
     * Some calls to Begin()/BeginChild() will return false. Will cycle through window depths then repeat.
     * Suggested use: add "io.ConfigDebugBeginReturnValue = io.KeyShift" in your main loop then occasionally press SHIFT.
     * Windows should be flickering while running.
     */
    public boolean getConfigDebugBeginReturnValueLoop() {
        return nGetConfigDebugBeginReturnValueLoop();
    }

    /**
     * Some calls to Begin()/BeginChild() will return false. Will cycle through window depths then repeat.
     * Suggested use: add "io.ConfigDebugBeginReturnValue = io.KeyShift" in your main loop then occasionally press SHIFT.
     * Windows should be flickering while running.
     */
    public void setConfigDebugBeginReturnValueLoop(final boolean value) {
        nSetConfigDebugBeginReturnValueLoop(value);
    }

    private native boolean nGetConfigDebugBeginReturnValueLoop(); /*
        return THIS->ConfigDebugBeginReturnValueLoop;
    */

    private native void nSetConfigDebugBeginReturnValueLoop(boolean value); /*
        THIS->ConfigDebugBeginReturnValueLoop = value;
    */

    /**
     * Option to deactivate io.AddFocusEvent(false) handling. May facilitate interactions with a debugger when focus loss leads to clearing inputs data.
     * Backends may have other side-effects on focus loss, so this will reduce side-effects but not necessary remove all of them.
     * Consider using e.g. Win32's IsDebuggerPresent() as an additional filter (or see ImOsIsDebuggerPresent() in imgui_test_engine/imgui_te_utils.cpp for a Unix compatible version).
     * Ignore io.AddFocusEvent(false), consequently not calling io.ClearInputKeys() in input processing.
     */
    public boolean getConfigDebugIgnoreFocusLoss() {
        return nGetConfigDebugIgnoreFocusLoss();
    }

    /**
     * Option to deactivate io.AddFocusEvent(false) handling. May facilitate interactions with a debugger when focus loss leads to clearing inputs data.
     * Backends may have other side-effects on focus loss, so this will reduce side-effects but not necessary remove all of them.
     * Consider using e.g. Win32's IsDebuggerPresent() as an additional filter (or see ImOsIsDebuggerPresent() in imgui_test_engine/imgui_te_utils.cpp for a Unix compatible version).
     * Ignore io.AddFocusEvent(false), consequently not calling io.ClearInputKeys() in input processing.
     */
    public void setConfigDebugIgnoreFocusLoss(final boolean value) {
        nSetConfigDebugIgnoreFocusLoss(value);
    }

    private native boolean nGetConfigDebugIgnoreFocusLoss(); /*
        return THIS->ConfigDebugIgnoreFocusLoss;
    */

    private native void nSetConfigDebugIgnoreFocusLoss(boolean value); /*
        THIS->ConfigDebugIgnoreFocusLoss = value;
    */

    /**
     * Option to audit .ini data
     * Save .ini data with extra comments (particularly helpful for Docking, but makes saving slower)
     */
    public boolean getConfigDebugIniSettings() {
        return nGetConfigDebugIniSettings();
    }

    /**
     * Option to audit .ini data
     * Save .ini data with extra comments (particularly helpful for Docking, but makes saving slower)
     */
    public void setConfigDebugIniSettings(final boolean value) {
        nSetConfigDebugIniSettings(value);
    }

    private native boolean nGetConfigDebugIniSettings(); /*
        return THIS->ConfigDebugIniSettings;
    */

    private native void nSetConfigDebugIniSettings(boolean value); /*
        THIS->ConfigDebugIniSettings = value;
    */

    //------------------------------------------------------------------
    // Platform Functions
    //------------------------------------------------------------------

    /**
     * Optional: Platform backend name (informational only! will be displayed in About Window) + User data for backend/wrappers to store their own stuff.
     */
    public String getBackendPlatformName() {
        return nGetBackendPlatformName();
    }

    /**
     * Optional: Platform backend name (informational only! will be displayed in About Window) + User data for backend/wrappers to store their own stuff.
     */
    public void setBackendPlatformName(final String value) {
        nSetBackendPlatformName(value);
    }

    private native String nGetBackendPlatformName(); /*
        return env->NewStringUTF(THIS->BackendPlatformName);
    */

    private native void nSetBackendPlatformName(String value); /*MANUAL
        auto value = obj_value == NULL ? NULL : (char*)env->GetStringUTFChars(obj_value, JNI_FALSE);
        SET_STRING_FIELD(THIS->BackendPlatformName, value);
        if (value != NULL) env->ReleaseStringUTFChars(obj_value, value);
    */

    public String getBackendRendererName() {
        return nGetBackendRendererName();
    }

    public void setBackendRendererName(final String value) {
        nSetBackendRendererName(value);
    }

    private native String nGetBackendRendererName(); /*
        return env->NewStringUTF(THIS->BackendRendererName);
    */

    private native void nSetBackendRendererName(String value); /*MANUAL
        auto value = obj_value == NULL ? NULL : (char*)env->GetStringUTFChars(obj_value, JNI_FALSE);
        SET_STRING_FIELD(THIS->BackendRendererName, value);
        if (value != NULL) env->ReleaseStringUTFChars(obj_value, value);
    */

    // Optional: Access OS clipboard
    // (default to use native Win32 clipIsMouseDraggingboard on Windows, otherwise uses a private clipboard. Override to access OS clipboard on other architectures)

    /*JNI
        jobject _setClipboardTextCallback = NULL;
        jobject _getClipboardTextCallback = NULL;

        void setClipboardTextStub(void* userData, const char* text) {
            Jni::CallImStrConsumer(Jni::GetEnv(), _setClipboardTextCallback, text);
        }

        const char* getClipboardTextStub(void* user_data) {
            JNIEnv* env = Jni::GetEnv();
            jstring jstr = Jni::CallImStrSupplier(env, _getClipboardTextCallback);
            return env->GetStringUTFChars(jstr, 0);
        }
     */

    public native void setSetClipboardTextFn(ImStrConsumer setClipboardTextCallback); /*
        if (_setClipboardTextCallback != NULL) {
            env->DeleteGlobalRef(_setClipboardTextCallback);
        }
        _setClipboardTextCallback = env->NewGlobalRef(setClipboardTextCallback);
        THIS->SetClipboardTextFn = setClipboardTextStub;
    */

    public native void setGetClipboardTextFn(ImStrSupplier getClipboardTextCallback); /*
        if (_getClipboardTextCallback != NULL) {
            env->DeleteGlobalRef(_getClipboardTextCallback);
        }
        _getClipboardTextCallback = env->NewGlobalRef(getClipboardTextCallback);
        THIS->GetClipboardTextFn = getClipboardTextStub;
    */

    // PlatformLocaleDecimalPoint was removed from ImGuiIO in imgui 1.92; the equivalent is
    // now 'style.LocaleDecimalPoint' (not currently surfaced in the Java binding).

    //------------------------------------------------------------------
    // Input - Call before calling NewFrame()
    //------------------------------------------------------------------

    // Input Functions

    /**
     * Queue a new key down/up event. Key should be "translated" (as in, generally ImGuiKey_A matches the key end-user would use to emit an 'A' character)
     */
    public void addKeyEvent(final int key, final boolean down) {
        nAddKeyEvent(key, down);
    }

    private native void nAddKeyEvent(int key, boolean down); /*
        THIS->AddKeyEvent(static_cast<ImGuiKey>(key), down);
    */

    /**
     * Queue a new key down/up event for analog values (e.g. ImGuiKey_Gamepad_ values). Dead-zones should be handled by the backend.
     */
    public void addKeyAnalogEvent(final int key, final boolean down, final float v) {
        nAddKeyAnalogEvent(key, down, v);
    }

    private native void nAddKeyAnalogEvent(int key, boolean down, float v); /*
        THIS->AddKeyAnalogEvent(static_cast<ImGuiKey>(key), down, v);
    */

    /**
     * Queue a mouse position update. Use -FLT_MAX,-FLT_MAX to signify no mouse (e.g. app not focused and not hovered)
     */
    public void addMousePosEvent(final float x, final float y) {
        nAddMousePosEvent(x, y);
    }

    private native void nAddMousePosEvent(float x, float y); /*
        THIS->AddMousePosEvent(x, y);
    */

    /**
     * Queue a mouse button change
     */
    public void addMouseButtonEvent(final int button, final boolean down) {
        nAddMouseButtonEvent(button, down);
    }

    private native void nAddMouseButtonEvent(int button, boolean down); /*
        THIS->AddMouseButtonEvent(button, down);
    */

    /**
     * Queue a mouse wheel update.
     */
    public void addMouseWheelEvent(final float whX, final float whY) {
        nAddMouseWheelEvent(whX, whY);
    }

    private native void nAddMouseWheelEvent(float whX, float whY); /*
        THIS->AddMouseWheelEvent(whX, whY);
    */

    /**
     * Queue a mouse source change (Mouse/TouchScreen/Pen)
     */
    public void addMouseSourceEvent(final int source) {
        nAddMouseSourceEvent(source);
    }

    private native void nAddMouseSourceEvent(int source); /*
        THIS->AddMouseSourceEvent(static_cast<ImGuiMouseSource>(source));
    */

    /**
     * Queue a mouse hovered viewport. Requires backend to set ImGuiBackendFlags_HasMouseHoveredViewport to call this (for multi-viewport support).
     */
    public void addMouseViewportEvent(final int id) {
        nAddMouseViewportEvent(id);
    }

    private native void nAddMouseViewportEvent(int id); /*
        THIS->AddMouseViewportEvent(static_cast<ImGuiID>(id));
    */

    /**
     * Queue a gain/loss of focus for the application (generally based on OS/platform focus of your window)
     */
    public void addFocusEvent(final boolean focused) {
        nAddFocusEvent(focused);
    }

    private native void nAddFocusEvent(boolean focused); /*
        THIS->AddFocusEvent(focused);
    */

    /**
     * Queue new character input.
     */
    public void addInputCharacter(final int c) {
        nAddInputCharacter(c);
    }

    private native void nAddInputCharacter(int c); /*
        THIS->AddInputCharacter((unsigned int)c);
    */

    /**
     * Queue new character input from a UTF-16 character, it can be a surrogate
     */
    public void addInputCharacterUTF16(final short c) {
        nAddInputCharacterUTF16(c);
    }

    private native void nAddInputCharacterUTF16(short c); /*
        THIS->AddInputCharacterUTF16((ImWchar16)c);
    */

    /**
     * Queue new characters input from a UTF-8 string.
     */
    public void addInputCharactersUTF8(final String str) {
        nAddInputCharactersUTF8(str);
    }

    private native void nAddInputCharactersUTF8(String str); /*MANUAL
        auto str = obj_str == NULL ? NULL : (char*)env->GetStringUTFChars(obj_str, JNI_FALSE);
        THIS->AddInputCharactersUTF8(str);
        if (str != NULL) env->ReleaseStringUTFChars(obj_str, str);
    */

    /**
     * [Optional] Specify index for legacy {@code <1.87} IsKeyXXX() functions with native indices + specify native keycode, scancode.
     */
    public void setKeyEventNativeData(final int key, final int nativeKeycode, final int nativeScancode) {
        nSetKeyEventNativeData(key, nativeKeycode, nativeScancode);
    }

    /**
     * [Optional] Specify index for legacy {@code <1.87} IsKeyXXX() functions with native indices + specify native keycode, scancode.
     */
    public void setKeyEventNativeData(final int key, final int nativeKeycode, final int nativeScancode, final int nativeLegacyIndex) {
        nSetKeyEventNativeData(key, nativeKeycode, nativeScancode, nativeLegacyIndex);
    }

    private native void nSetKeyEventNativeData(int key, int nativeKeycode, int nativeScancode); /*
        THIS->SetKeyEventNativeData(static_cast<ImGuiKey>(key), nativeKeycode, nativeScancode);
    */

    private native void nSetKeyEventNativeData(int key, int nativeKeycode, int nativeScancode, int nativeLegacyIndex); /*
        THIS->SetKeyEventNativeData(static_cast<ImGuiKey>(key), nativeKeycode, nativeScancode, nativeLegacyIndex);
    */

    /**
     * Set master flag for accepting key/mouse/text events (default to true). Useful if you have native dialog boxes that are interrupting your application loop/refresh, and you want to disable events being queued while your app is frozen.
     */
    public void setAppAcceptingEvents(final boolean acceptingEvents) {
        nSetAppAcceptingEvents(acceptingEvents);
    }

    private native void nSetAppAcceptingEvents(boolean acceptingEvents); /*
        THIS->SetAppAcceptingEvents(acceptingEvents);
    */

    /**
     * Clear all incoming events.
     */
    public void clearEventsQueue() {
        nClearEventsQueue();
    }

    private native void nClearEventsQueue(); /*
        THIS->ClearEventsQueue();
    */

    /**
     * Clear current keyboard/gamepad state + current frame text input buffer. Equivalent to releasing all keys/buttons.
     */
    public void clearInputKeys() {
        nClearInputKeys();
    }

    private native void nClearInputKeys(); /*
        THIS->ClearInputKeys();
    */

    /**
     * Clear current mouse state.
     */
    public void clearInputMouse() {
        nClearInputMouse();
    }

    private native void nClearInputMouse(); /*
        THIS->ClearInputMouse();
    */

    //------------------------------------------------------------------
    // Output - Updated by NewFrame() or EndFrame()/Render()
    // (when reading from the io.WantCaptureMouse, io.WantCaptureKeyboard flags to dispatch your inputs, it is
    //  generally easier and more correct to use their state BEFORE calling NewFrame(). See FAQ for details!)
    //------------------------------------------------------------------

    /**
     * Set when Dear ImGui will use mouse inputs, in this case do not dispatch them to your main game/application
     * (either way, always pass on mouse inputs to imgui).
     * (e.g. unclicked mouse is hovering over an imgui window, widget is active, mouse was clicked over an imgui window, etc.).
     */
    public boolean getWantCaptureMouse() {
        return nGetWantCaptureMouse();
    }

    /**
     * Set when Dear ImGui will use mouse inputs, in this case do not dispatch them to your main game/application
     * (either way, always pass on mouse inputs to imgui).
     * (e.g. unclicked mouse is hovering over an imgui window, widget is active, mouse was clicked over an imgui window, etc.).
     */
    public void setWantCaptureMouse(final boolean value) {
        nSetWantCaptureMouse(value);
    }

    private native boolean nGetWantCaptureMouse(); /*
        return THIS->WantCaptureMouse;
    */

    private native void nSetWantCaptureMouse(boolean value); /*
        THIS->WantCaptureMouse = value;
    */

    /**
     * Set when Dear ImGui will use keyboard inputs, in this case do not dispatch them to your main game/application
     * (either way, always pass keyboard inputs to imgui). (e.g. InputText active, or an imgui window is focused and navigation is enabled, etc.).
     */
    public boolean getWantCaptureKeyboard() {
        return nGetWantCaptureKeyboard();
    }

    /**
     * Set when Dear ImGui will use keyboard inputs, in this case do not dispatch them to your main game/application
     * (either way, always pass keyboard inputs to imgui). (e.g. InputText active, or an imgui window is focused and navigation is enabled, etc.).
     */
    public void setWantCaptureKeyboard(final boolean value) {
        nSetWantCaptureKeyboard(value);
    }

    private native boolean nGetWantCaptureKeyboard(); /*
        return THIS->WantCaptureKeyboard;
    */

    private native void nSetWantCaptureKeyboard(boolean value); /*
        THIS->WantCaptureKeyboard = value;
    */

    /**
     * Mobile/console: when set, you may display an on-screen keyboard.
     * This is set by Dear ImGui when it wants textual keyboard input to happen (e.g. when a InputText widget is active).
     */
    public boolean getWantTextInput() {
        return nGetWantTextInput();
    }

    /**
     * Mobile/console: when set, you may display an on-screen keyboard.
     * This is set by Dear ImGui when it wants textual keyboard input to happen (e.g. when a InputText widget is active).
     */
    public void setWantTextInput(final boolean value) {
        nSetWantTextInput(value);
    }

    private native boolean nGetWantTextInput(); /*
        return THIS->WantTextInput;
    */

    private native void nSetWantTextInput(boolean value); /*
        THIS->WantTextInput = value;
    */

    /**
     * MousePos has been altered, backend should reposition mouse on next frame. Rarely used! Set only when ImGuiConfigFlags_NavEnableSetMousePos flag is enabled.
     */
    public boolean getWantSetMousePos() {
        return nGetWantSetMousePos();
    }

    /**
     * MousePos has been altered, backend should reposition mouse on next frame. Rarely used! Set only when ImGuiConfigFlags_NavEnableSetMousePos flag is enabled.
     */
    public void setWantSetMousePos(final boolean value) {
        nSetWantSetMousePos(value);
    }

    private native boolean nGetWantSetMousePos(); /*
        return THIS->WantSetMousePos;
    */

    private native void nSetWantSetMousePos(boolean value); /*
        THIS->WantSetMousePos = value;
    */

    /**
     * When manual .ini load/save is active (io.IniFilename == NULL),
     * this will be set to notify your application that you can call SaveIniSettingsToMemory() and save yourself.
     * Important: clear io.WantSaveIniSettings yourself after saving!
     */
    public boolean getWantSaveIniSettings() {
        return nGetWantSaveIniSettings();
    }

    /**
     * When manual .ini load/save is active (io.IniFilename == NULL),
     * this will be set to notify your application that you can call SaveIniSettingsToMemory() and save yourself.
     * Important: clear io.WantSaveIniSettings yourself after saving!
     */
    public void setWantSaveIniSettings(final boolean value) {
        nSetWantSaveIniSettings(value);
    }

    private native boolean nGetWantSaveIniSettings(); /*
        return THIS->WantSaveIniSettings;
    */

    private native void nSetWantSaveIniSettings(boolean value); /*
        THIS->WantSaveIniSettings = value;
    */

    /**
     * Keyboard/Gamepad navigation is currently allowed (will handle ImGuiKey_NavXXX events) = a window is focused
     * and it doesn't use the ImGuiWindowFlags_NoNavInputs flag.
     */
    public boolean getNavActive() {
        return nGetNavActive();
    }

    /**
     * Keyboard/Gamepad navigation is currently allowed (will handle ImGuiKey_NavXXX events) = a window is focused
     * and it doesn't use the ImGuiWindowFlags_NoNavInputs flag.
     */
    public void setNavActive(final boolean value) {
        nSetNavActive(value);
    }

    private native boolean nGetNavActive(); /*
        return THIS->NavActive;
    */

    private native void nSetNavActive(boolean value); /*
        THIS->NavActive = value;
    */

    /**
     * Keyboard/Gamepad navigation is visible and allowed (will handle ImGuiKey_NavXXX events).
     */
    public boolean getNavVisible() {
        return nGetNavVisible();
    }

    /**
     * Keyboard/Gamepad navigation is visible and allowed (will handle ImGuiKey_NavXXX events).
     */
    public void setNavVisible(final boolean value) {
        nSetNavVisible(value);
    }

    private native boolean nGetNavVisible(); /*
        return THIS->NavVisible;
    */

    private native void nSetNavVisible(boolean value); /*
        THIS->NavVisible = value;
    */

    /**
     * Estimate of application framerate (rolling average over 60 frames, based on io.DeltaTime), in frame per second.
     * Solely for convenience.
     * Slow applications may not want to use a moving average or may want to reset underlying buffers occasionally.
     */
    public float getFramerate() {
        return nGetFramerate();
    }

    /**
     * Estimate of application framerate (rolling average over 60 frames, based on io.DeltaTime), in frame per second.
     * Solely for convenience.
     * Slow applications may not want to use a moving average or may want to reset underlying buffers occasionally.
     */
    public void setFramerate(final float value) {
        nSetFramerate(value);
    }

    private native float nGetFramerate(); /*
        return THIS->Framerate;
    */

    private native void nSetFramerate(float value); /*
        THIS->Framerate = value;
    */

    /**
     * Vertices output during last call to Render()
     */
    public int getMetricsRenderVertices() {
        return nGetMetricsRenderVertices();
    }

    /**
     * Vertices output during last call to Render()
     */
    public void setMetricsRenderVertices(final int value) {
        nSetMetricsRenderVertices(value);
    }

    private native int nGetMetricsRenderVertices(); /*
        return THIS->MetricsRenderVertices;
    */

    private native void nSetMetricsRenderVertices(int value); /*
        THIS->MetricsRenderVertices = value;
    */

    /**
     * Indices output during last call to Render() = number of triangles * 3
     */
    public int getMetricsRenderIndices() {
        return nGetMetricsRenderIndices();
    }

    /**
     * Indices output during last call to Render() = number of triangles * 3
     */
    public void setMetricsRenderIndices(final int value) {
        nSetMetricsRenderIndices(value);
    }

    private native int nGetMetricsRenderIndices(); /*
        return THIS->MetricsRenderIndices;
    */

    private native void nSetMetricsRenderIndices(int value); /*
        THIS->MetricsRenderIndices = value;
    */

    /**
     * Number of visible windows
     */
    public int getMetricsRenderWindows() {
        return nGetMetricsRenderWindows();
    }

    /**
     * Number of visible windows
     */
    public void setMetricsRenderWindows(final int value) {
        nSetMetricsRenderWindows(value);
    }

    private native int nGetMetricsRenderWindows(); /*
        return THIS->MetricsRenderWindows;
    */

    private native void nSetMetricsRenderWindows(int value); /*
        THIS->MetricsRenderWindows = value;
    */

    /**
     * Number of active windows
     */
    public int getMetricsActiveWindows() {
        return nGetMetricsActiveWindows();
    }

    /**
     * Number of active windows
     */
    public void setMetricsActiveWindows(final int value) {
        nSetMetricsActiveWindows(value);
    }

    private native int nGetMetricsActiveWindows(); /*
        return THIS->MetricsActiveWindows;
    */

    private native void nSetMetricsActiveWindows(int value); /*
        THIS->MetricsActiveWindows = value;
    */

    /**
     * Mouse delta. Note that this is zero if either current or previous position are invalid (-FLT_MAX,-FLT_MAX), so a disappearing/reappearing mouse won't have a huge delta.
     */
    public ImVec2 getMouseDelta() {
        final ImVec2 dst = new ImVec2();
        nGetMouseDelta(dst);
        return dst;
    }

    /**
     * Mouse delta. Note that this is zero if either current or previous position are invalid (-FLT_MAX,-FLT_MAX), so a disappearing/reappearing mouse won't have a huge delta.
     */
    public float getMouseDeltaX() {
        return nGetMouseDeltaX();
    }

    /**
     * Mouse delta. Note that this is zero if either current or previous position are invalid (-FLT_MAX,-FLT_MAX), so a disappearing/reappearing mouse won't have a huge delta.
     */
    public float getMouseDeltaY() {
        return nGetMouseDeltaY();
    }

    /**
     * Mouse delta. Note that this is zero if either current or previous position are invalid (-FLT_MAX,-FLT_MAX), so a disappearing/reappearing mouse won't have a huge delta.
     */
    public void getMouseDelta(final ImVec2 dst) {
        nGetMouseDelta(dst);
    }

    /**
     * Mouse delta. Note that this is zero if either current or previous position are invalid (-FLT_MAX,-FLT_MAX), so a disappearing/reappearing mouse won't have a huge delta.
     */
    public void setMouseDelta(final ImVec2 value) {
        nSetMouseDelta(value.x, value.y);
    }

    /**
     * Mouse delta. Note that this is zero if either current or previous position are invalid (-FLT_MAX,-FLT_MAX), so a disappearing/reappearing mouse won't have a huge delta.
     */
    public void setMouseDelta(final float valueX, final float valueY) {
        nSetMouseDelta(valueX, valueY);
    }

    private native void nGetMouseDelta(ImVec2 dst); /*
        Jni::ImVec2Cpy(env, THIS->MouseDelta, dst);
    */

    private native float nGetMouseDeltaX(); /*
        return THIS->MouseDelta.x;
    */

    private native float nGetMouseDeltaY(); /*
        return THIS->MouseDelta.y;
    */

    private native void nSetMouseDelta(float valueX, float valueY); /*MANUAL
        ImVec2 value = ImVec2(valueX, valueY);
        THIS->MouseDelta = value;
    */

    //------------------------------------------------------------------
    // [Internal] Dear ImGui will maintain those fields. Forward compatibility not guaranteed!
    //------------------------------------------------------------------

    private static final ImGuiContext _GETCTX_1 = new ImGuiContext(0);

    /**
     * Parent UI context (needs to be set explicitly by parent).
     */
    public ImGuiContext getCtx() {
        _GETCTX_1.ptr = nGetCtx();
        return _GETCTX_1;
    }

    /**
     * Parent UI context (needs to be set explicitly by parent).
     */
    public void setCtx(final ImGuiContext value) {
        nSetCtx(value.ptr);
    }

    private native long nGetCtx(); /*
        return (uintptr_t)THIS->Ctx;
    */

    private native void nSetCtx(long value); /*
        THIS->Ctx = reinterpret_cast<ImGuiContext*>(value);
    */

    /**
     * Mouse position, in pixels. Set to ImVec2(-FLT_MAX, -FLT_MAX) if mouse is unavailable (on another screen, etc.)
     */
    public ImVec2 getMousePos() {
        final ImVec2 dst = new ImVec2();
        nGetMousePos(dst);
        return dst;
    }

    /**
     * Mouse position, in pixels. Set to ImVec2(-FLT_MAX, -FLT_MAX) if mouse is unavailable (on another screen, etc.)
     */
    public float getMousePosX() {
        return nGetMousePosX();
    }

    /**
     * Mouse position, in pixels. Set to ImVec2(-FLT_MAX, -FLT_MAX) if mouse is unavailable (on another screen, etc.)
     */
    public float getMousePosY() {
        return nGetMousePosY();
    }

    /**
     * Mouse position, in pixels. Set to ImVec2(-FLT_MAX, -FLT_MAX) if mouse is unavailable (on another screen, etc.)
     */
    public void getMousePos(final ImVec2 dst) {
        nGetMousePos(dst);
    }

    /**
     * Mouse position, in pixels. Set to ImVec2(-FLT_MAX, -FLT_MAX) if mouse is unavailable (on another screen, etc.)
     */
    public void setMousePos(final ImVec2 value) {
        nSetMousePos(value.x, value.y);
    }

    /**
     * Mouse position, in pixels. Set to ImVec2(-FLT_MAX, -FLT_MAX) if mouse is unavailable (on another screen, etc.)
     */
    public void setMousePos(final float valueX, final float valueY) {
        nSetMousePos(valueX, valueY);
    }

    private native void nGetMousePos(ImVec2 dst); /*
        Jni::ImVec2Cpy(env, THIS->MousePos, dst);
    */

    private native float nGetMousePosX(); /*
        return THIS->MousePos.x;
    */

    private native float nGetMousePosY(); /*
        return THIS->MousePos.y;
    */

    private native void nSetMousePos(float valueX, float valueY); /*MANUAL
        ImVec2 value = ImVec2(valueX, valueY);
        THIS->MousePos = value;
    */

    /**
     * Mouse buttons: 0=left, 1=right, 2=middle + extras (ImGuiMouseButton_COUNT == 5). Dear ImGui mostly uses left and right buttons.
     * Others buttons allows us to track if the mouse is being used by your application + available to user as a convenience via IsMouse** API.
     */
    public boolean[] getMouseDown() {
        return nGetMouseDown();
    }

    /**
     * Mouse buttons: 0=left, 1=right, 2=middle + extras (ImGuiMouseButton_COUNT == 5). Dear ImGui mostly uses left and right buttons.
     * Others buttons allows us to track if the mouse is being used by your application + available to user as a convenience via IsMouse** API.
     */
    public boolean getMouseDown(final int idx) {
        return nGetMouseDown(idx);
    }

    /**
     * Mouse buttons: 0=left, 1=right, 2=middle + extras (ImGuiMouseButton_COUNT == 5). Dear ImGui mostly uses left and right buttons.
     * Others buttons allows us to track if the mouse is being used by your application + available to user as a convenience via IsMouse** API.
     */
    public void setMouseDown(final boolean[] value) {
        nSetMouseDown(value);
    }

    /**
     * Mouse buttons: 0=left, 1=right, 2=middle + extras (ImGuiMouseButton_COUNT == 5). Dear ImGui mostly uses left and right buttons.
     * Others buttons allows us to track if the mouse is being used by your application + available to user as a convenience via IsMouse** API.
     */
    public void setMouseDown(final int idx, final boolean value) {
        nSetMouseDown(idx, value);
    }

    private native boolean[] nGetMouseDown(); /*
        jboolean jBuf[5];
        for (int i = 0; i < 5; i++)
            jBuf[i] = THIS->MouseDown[i];
        jbooleanArray result = env->NewBooleanArray(5);
        env->SetBooleanArrayRegion(result, 0, 5, jBuf);
        return result;
    */

    private native boolean nGetMouseDown(int idx); /*
        return THIS->MouseDown[idx];
    */

    private native void nSetMouseDown(boolean[] value); /*
        for (int i = 0; i < 5; i++)
            THIS->MouseDown[i] = value[i];
    */

    private native void nSetMouseDown(int idx, boolean value); /*
        THIS->MouseDown[idx] = value;
    */

    /**
     * Mouse wheel Vertical: 1 unit scrolls about 5 lines text.
     */
    public float getMouseWheel() {
        return nGetMouseWheel();
    }

    /**
     * Mouse wheel Vertical: 1 unit scrolls about 5 lines text.
     */
    public void setMouseWheel(final float value) {
        nSetMouseWheel(value);
    }

    private native float nGetMouseWheel(); /*
        return THIS->MouseWheel;
    */

    private native void nSetMouseWheel(float value); /*
        THIS->MouseWheel = value;
    */

    /**
     * Mouse wheel Horizontal. Most users don't have a mouse with an horizontal wheel, may not be filled by all backends.
     */
    public float getMouseWheelH() {
        return nGetMouseWheelH();
    }

    /**
     * Mouse wheel Horizontal. Most users don't have a mouse with an horizontal wheel, may not be filled by all backends.
     */
    public void setMouseWheelH(final float value) {
        nSetMouseWheelH(value);
    }

    private native float nGetMouseWheelH(); /*
        return THIS->MouseWheelH;
    */

    private native void nSetMouseWheelH(float value); /*
        THIS->MouseWheelH = value;
    */

    /**
     * (Optional) When using multiple viewports: viewport the OS mouse cursor is hovering _IGNORING_ viewports with the ImGuiViewportFlags_NoInputs flag,
     * and _REGARDLESS_ of whether another viewport is focused. Set io.BackendFlags |= ImGuiBackendFlags_HasMouseHoveredViewport if you can provide this info.
     * If you don't imgui will infer the value using the rectangles and last focused time of the viewports it knows about (ignoring other OS windows).
     */
    public int getMouseHoveredViewport() {
        return nGetMouseHoveredViewport();
    }

    /**
     * (Optional) When using multiple viewports: viewport the OS mouse cursor is hovering _IGNORING_ viewports with the ImGuiViewportFlags_NoInputs flag,
     * and _REGARDLESS_ of whether another viewport is focused. Set io.BackendFlags |= ImGuiBackendFlags_HasMouseHoveredViewport if you can provide this info.
     * If you don't imgui will infer the value using the rectangles and last focused time of the viewports it knows about (ignoring other OS windows).
     */
    public void setMouseHoveredViewport(final int value) {
        nSetMouseHoveredViewport(value);
    }

    private native int nGetMouseHoveredViewport(); /*
        return THIS->MouseHoveredViewport;
    */

    private native void nSetMouseHoveredViewport(int value); /*
        THIS->MouseHoveredViewport = value;
    */

    /**
     * Keyboard modifier pressed: Control
     */
    public boolean getKeyCtrl() {
        return nGetKeyCtrl();
    }

    /**
     * Keyboard modifier pressed: Control
     */
    public void setKeyCtrl(final boolean value) {
        nSetKeyCtrl(value);
    }

    private native boolean nGetKeyCtrl(); /*
        return THIS->KeyCtrl;
    */

    private native void nSetKeyCtrl(boolean value); /*
        THIS->KeyCtrl = value;
    */

    /**
     * Keyboard modifier pressed: Shift
     */
    public boolean getKeyShift() {
        return nGetKeyShift();
    }

    /**
     * Keyboard modifier pressed: Shift
     */
    public void setKeyShift(final boolean value) {
        nSetKeyShift(value);
    }

    private native boolean nGetKeyShift(); /*
        return THIS->KeyShift;
    */

    private native void nSetKeyShift(boolean value); /*
        THIS->KeyShift = value;
    */

    /**
     * Keyboard modifier pressed: Alt
     */
    public boolean getKeyAlt() {
        return nGetKeyAlt();
    }

    /**
     * Keyboard modifier pressed: Alt
     */
    public void setKeyAlt(final boolean value) {
        nSetKeyAlt(value);
    }

    private native boolean nGetKeyAlt(); /*
        return THIS->KeyAlt;
    */

    private native void nSetKeyAlt(boolean value); /*
        THIS->KeyAlt = value;
    */

    /**
     * Keyboard modifier pressed: Cmd/Super/Windows
     */
    public boolean getKeySuper() {
        return nGetKeySuper();
    }

    /**
     * Keyboard modifier pressed: Cmd/Super/Windows
     */
    public void setKeySuper(final boolean value) {
        nSetKeySuper(value);
    }

    private native boolean nGetKeySuper(); /*
        return THIS->KeySuper;
    */

    private native void nSetKeySuper(boolean value); /*
        THIS->KeySuper = value;
    */

    // Other state maintained from data above + IO function calls

    /**
     * Key mods flags (same as io.KeyCtrl/KeyShift/KeyAlt/KeySuper but merged into flags), updated by NewFrame()
     */
    public int getKeyMods() {
        return nGetKeyMods();
    }

    /**
     * Key mods flags (same as io.KeyCtrl/KeyShift/KeyAlt/KeySuper but merged into flags), updated by NewFrame()
     */
    public void setKeyMods(final int value) {
        nSetKeyMods(value);
    }

    private native int nGetKeyMods(); /*
        return THIS->KeyMods;
    */

    private native void nSetKeyMods(int value); /*
        THIS->KeyMods = value;
    */

    /**
     * Key state for all known keys. Use IsKeyXXX() functions to access this.
     */
    public ImGuiKeyData[] getKeysData() {
        return nGetKeysData();
    }

    /**
     * Key state for all known keys. Use IsKeyXXX() functions to access this.
     */
    public void setKeysData(final ImGuiKeyData[] value) {
        nSetKeysData(value);
    }

    private native ImGuiKeyData[] nGetKeysData(); /*
        return Jni::NewImGuiKeyDataArray(env, THIS->KeysData, ImGuiKey_NamedKey_COUNT);
    */

    private native void nSetKeysData(ImGuiKeyData[] value); /*
        Jni::ImGuiKeyDataArrayCpy(env, value, THIS->KeysData, ImGuiKey_NamedKey_COUNT);
    */

    /**
     * Alternative to WantCaptureMouse: (WantCaptureMouse == true {@code &&} WantCaptureMouseUnlessPopupClose == false) when a click over void is expected to close a popup.
     */
    public boolean getWantCaptureMouseUnlessPopupClose() {
        return nGetWantCaptureMouseUnlessPopupClose();
    }

    /**
     * Alternative to WantCaptureMouse: (WantCaptureMouse == true {@code &&} WantCaptureMouseUnlessPopupClose == false) when a click over void is expected to close a popup.
     */
    public void setWantCaptureMouseUnlessPopupClose(final boolean value) {
        nSetWantCaptureMouseUnlessPopupClose(value);
    }

    private native boolean nGetWantCaptureMouseUnlessPopupClose(); /*
        return THIS->WantCaptureMouseUnlessPopupClose;
    */

    private native void nSetWantCaptureMouseUnlessPopupClose(boolean value); /*
        THIS->WantCaptureMouseUnlessPopupClose = value;
    */

    /**
     * Previous mouse position (note that MouseDelta is not necessary == MousePos-MousePosPrev, in case either position is invalid)
     */
    public ImVec2 getMousePosPrev() {
        final ImVec2 dst = new ImVec2();
        nGetMousePosPrev(dst);
        return dst;
    }

    /**
     * Previous mouse position (note that MouseDelta is not necessary == MousePos-MousePosPrev, in case either position is invalid)
     */
    public float getMousePosPrevX() {
        return nGetMousePosPrevX();
    }

    /**
     * Previous mouse position (note that MouseDelta is not necessary == MousePos-MousePosPrev, in case either position is invalid)
     */
    public float getMousePosPrevY() {
        return nGetMousePosPrevY();
    }

    /**
     * Previous mouse position (note that MouseDelta is not necessary == MousePos-MousePosPrev, in case either position is invalid)
     */
    public void getMousePosPrev(final ImVec2 dst) {
        nGetMousePosPrev(dst);
    }

    /**
     * Previous mouse position (note that MouseDelta is not necessary == MousePos-MousePosPrev, in case either position is invalid)
     */
    public void setMousePosPrev(final ImVec2 value) {
        nSetMousePosPrev(value.x, value.y);
    }

    /**
     * Previous mouse position (note that MouseDelta is not necessary == MousePos-MousePosPrev, in case either position is invalid)
     */
    public void setMousePosPrev(final float valueX, final float valueY) {
        nSetMousePosPrev(valueX, valueY);
    }

    private native void nGetMousePosPrev(ImVec2 dst); /*
        Jni::ImVec2Cpy(env, THIS->MousePosPrev, dst);
    */

    private native float nGetMousePosPrevX(); /*
        return THIS->MousePosPrev.x;
    */

    private native float nGetMousePosPrevY(); /*
        return THIS->MousePosPrev.y;
    */

    private native void nSetMousePosPrev(float valueX, float valueY); /*MANUAL
        ImVec2 value = ImVec2(valueX, valueY);
        THIS->MousePosPrev = value;
    */

    /**
     * Position at time of clicking.
     */
    public ImVec2[] getMouseClickedPos() {
        return nGetMouseClickedPos();
    }

    /**
     * Position at time of clicking.
     */
    public void setMouseClickedPos(final ImVec2[] value) {
        nSetMouseClickedPos(value);
    }

    private native ImVec2[] nGetMouseClickedPos(); /*
        return Jni::NewImVec2Array(env, THIS->MouseClickedPos, 5);
    */

    private native void nSetMouseClickedPos(ImVec2[] value); /*
        Jni::ImVec2ArrayCpy(env, value, THIS->MouseClickedPos, 5);
    */

    /**
     * Time of last click (used to figure out double-click)
     */
    public double[] getMouseClickedTime() {
        return nGetMouseClickedTime();
    }

    /**
     * Time of last click (used to figure out double-click)
     */
    public double getMouseClickedTime(final int idx) {
        return nGetMouseClickedTime(idx);
    }

    /**
     * Time of last click (used to figure out double-click)
     */
    public void setMouseClickedTime(final double[] value) {
        nSetMouseClickedTime(value);
    }

    /**
     * Time of last click (used to figure out double-click)
     */
    public void setMouseClickedTime(final int idx, final double value) {
        nSetMouseClickedTime(idx, value);
    }

    private native double[] nGetMouseClickedTime(); /*
        jdouble jBuf[5];
        for (int i = 0; i < 5; i++)
            jBuf[i] = THIS->MouseClickedTime[i];
        jdoubleArray result = env->NewDoubleArray(5);
        env->SetDoubleArrayRegion(result, 0, 5, jBuf);
        return result;
    */

    private native double nGetMouseClickedTime(int idx); /*
        return THIS->MouseClickedTime[idx];
    */

    private native void nSetMouseClickedTime(double[] value); /*
        for (int i = 0; i < 5; i++)
            THIS->MouseClickedTime[i] = value[i];
    */

    private native void nSetMouseClickedTime(int idx, double value); /*
        THIS->MouseClickedTime[idx] = value;
    */

    /**
     * Mouse button went from !Down to Down (same as MouseClickedCount[x] != 0)
     */
    public boolean[] getMouseClicked() {
        return nGetMouseClicked();
    }

    /**
     * Mouse button went from !Down to Down (same as MouseClickedCount[x] != 0)
     */
    public boolean getMouseClicked(final int idx) {
        return nGetMouseClicked(idx);
    }

    /**
     * Mouse button went from !Down to Down (same as MouseClickedCount[x] != 0)
     */
    public void setMouseClicked(final boolean[] value) {
        nSetMouseClicked(value);
    }

    /**
     * Mouse button went from !Down to Down (same as MouseClickedCount[x] != 0)
     */
    public void setMouseClicked(final int idx, final boolean value) {
        nSetMouseClicked(idx, value);
    }

    private native boolean[] nGetMouseClicked(); /*
        jboolean jBuf[5];
        for (int i = 0; i < 5; i++)
            jBuf[i] = THIS->MouseClicked[i];
        jbooleanArray result = env->NewBooleanArray(5);
        env->SetBooleanArrayRegion(result, 0, 5, jBuf);
        return result;
    */

    private native boolean nGetMouseClicked(int idx); /*
        return THIS->MouseClicked[idx];
    */

    private native void nSetMouseClicked(boolean[] value); /*
        for (int i = 0; i < 5; i++)
            THIS->MouseClicked[i] = value[i];
    */

    private native void nSetMouseClicked(int idx, boolean value); /*
        THIS->MouseClicked[idx] = value;
    */

    /**
     * Has mouse button been double-clicked? (same as MouseClickedCount[x] == 2)
     */
    public boolean[] getMouseDoubleClicked() {
        return nGetMouseDoubleClicked();
    }

    /**
     * Has mouse button been double-clicked? (same as MouseClickedCount[x] == 2)
     */
    public boolean getMouseDoubleClicked(final int idx) {
        return nGetMouseDoubleClicked(idx);
    }

    /**
     * Has mouse button been double-clicked? (same as MouseClickedCount[x] == 2)
     */
    public void setMouseDoubleClicked(final boolean[] value) {
        nSetMouseDoubleClicked(value);
    }

    /**
     * Has mouse button been double-clicked? (same as MouseClickedCount[x] == 2)
     */
    public void setMouseDoubleClicked(final int idx, final boolean value) {
        nSetMouseDoubleClicked(idx, value);
    }

    private native boolean[] nGetMouseDoubleClicked(); /*
        jboolean jBuf[5];
        for (int i = 0; i < 5; i++)
            jBuf[i] = THIS->MouseDoubleClicked[i];
        jbooleanArray result = env->NewBooleanArray(5);
        env->SetBooleanArrayRegion(result, 0, 5, jBuf);
        return result;
    */

    private native boolean nGetMouseDoubleClicked(int idx); /*
        return THIS->MouseDoubleClicked[idx];
    */

    private native void nSetMouseDoubleClicked(boolean[] value); /*
        for (int i = 0; i < 5; i++)
            THIS->MouseDoubleClicked[i] = value[i];
    */

    private native void nSetMouseDoubleClicked(int idx, boolean value); /*
        THIS->MouseDoubleClicked[idx] = value;
    */

    /**
     * == 0 (not clicked), == 1 (same as MouseClicked[]), == 2 (double-clicked), == 3 (triple-clicked) etc. when going from !Down to Down
     */
    public int[] getMouseClickedCount() {
        return nGetMouseClickedCount();
    }

    /**
     * == 0 (not clicked), == 1 (same as MouseClicked[]), == 2 (double-clicked), == 3 (triple-clicked) etc. when going from !Down to Down
     */
    public int getMouseClickedCount(final int idx) {
        return nGetMouseClickedCount(idx);
    }

    /**
     * == 0 (not clicked), == 1 (same as MouseClicked[]), == 2 (double-clicked), == 3 (triple-clicked) etc. when going from !Down to Down
     */
    public void setMouseClickedCount(final int[] value) {
        nSetMouseClickedCount(value);
    }

    /**
     * == 0 (not clicked), == 1 (same as MouseClicked[]), == 2 (double-clicked), == 3 (triple-clicked) etc. when going from !Down to Down
     */
    public void setMouseClickedCount(final int idx, final int value) {
        nSetMouseClickedCount(idx, value);
    }

    private native int[] nGetMouseClickedCount(); /*
        jint jBuf[5];
        for (int i = 0; i < 5; i++)
            jBuf[i] = THIS->MouseClickedCount[i];
        jintArray result = env->NewIntArray(5);
        env->SetIntArrayRegion(result, 0, 5, jBuf);
        return result;
    */

    private native int nGetMouseClickedCount(int idx); /*
        return THIS->MouseClickedCount[idx];
    */

    private native void nSetMouseClickedCount(int[] value); /*
        for (int i = 0; i < 5; i++)
            THIS->MouseClickedCount[i] = value[i];
    */

    private native void nSetMouseClickedCount(int idx, int value); /*
        THIS->MouseClickedCount[idx] = value;
    */

    /**
     * Count successive number of clicks. Stays valid after mouse release. Reset after another click is done.
     */
    public int[] getMouseClickedLastCount() {
        return nGetMouseClickedLastCount();
    }

    /**
     * Count successive number of clicks. Stays valid after mouse release. Reset after another click is done.
     */
    public int getMouseClickedLastCount(final int idx) {
        return nGetMouseClickedLastCount(idx);
    }

    /**
     * Count successive number of clicks. Stays valid after mouse release. Reset after another click is done.
     */
    public void setMouseClickedLastCount(final int[] value) {
        nSetMouseClickedLastCount(value);
    }

    /**
     * Count successive number of clicks. Stays valid after mouse release. Reset after another click is done.
     */
    public void setMouseClickedLastCount(final int idx, final int value) {
        nSetMouseClickedLastCount(idx, value);
    }

    private native int[] nGetMouseClickedLastCount(); /*
        jint jBuf[5];
        for (int i = 0; i < 5; i++)
            jBuf[i] = THIS->MouseClickedLastCount[i];
        jintArray result = env->NewIntArray(5);
        env->SetIntArrayRegion(result, 0, 5, jBuf);
        return result;
    */

    private native int nGetMouseClickedLastCount(int idx); /*
        return THIS->MouseClickedLastCount[idx];
    */

    private native void nSetMouseClickedLastCount(int[] value); /*
        for (int i = 0; i < 5; i++)
            THIS->MouseClickedLastCount[i] = value[i];
    */

    private native void nSetMouseClickedLastCount(int idx, int value); /*
        THIS->MouseClickedLastCount[idx] = value;
    */

    /**
     * Mouse button went from Down to !Down
     */
    public boolean[] getMouseReleased() {
        return nGetMouseReleased();
    }

    /**
     * Mouse button went from Down to !Down
     */
    public boolean getMouseReleased(final int idx) {
        return nGetMouseReleased(idx);
    }

    /**
     * Mouse button went from Down to !Down
     */
    public void setMouseReleased(final boolean[] value) {
        nSetMouseReleased(value);
    }

    /**
     * Mouse button went from Down to !Down
     */
    public void setMouseReleased(final int idx, final boolean value) {
        nSetMouseReleased(idx, value);
    }

    private native boolean[] nGetMouseReleased(); /*
        jboolean jBuf[5];
        for (int i = 0; i < 5; i++)
            jBuf[i] = THIS->MouseReleased[i];
        jbooleanArray result = env->NewBooleanArray(5);
        env->SetBooleanArrayRegion(result, 0, 5, jBuf);
        return result;
    */

    private native boolean nGetMouseReleased(int idx); /*
        return THIS->MouseReleased[idx];
    */

    private native void nSetMouseReleased(boolean[] value); /*
        for (int i = 0; i < 5; i++)
            THIS->MouseReleased[i] = value[i];
    */

    private native void nSetMouseReleased(int idx, boolean value); /*
        THIS->MouseReleased[idx] = value;
    */

    /**
     * Track if button was clicked inside a dear imgui window or over void blocked by a popup. We don't request mouse capture from the application if click started outside ImGui bounds.
     */
    public boolean[] getMouseDownOwned() {
        return nGetMouseDownOwned();
    }

    /**
     * Track if button was clicked inside a dear imgui window or over void blocked by a popup. We don't request mouse capture from the application if click started outside ImGui bounds.
     */
    public boolean getMouseDownOwned(final int idx) {
        return nGetMouseDownOwned(idx);
    }

    /**
     * Track if button was clicked inside a dear imgui window or over void blocked by a popup. We don't request mouse capture from the application if click started outside ImGui bounds.
     */
    public void setMouseDownOwned(final boolean[] value) {
        nSetMouseDownOwned(value);
    }

    /**
     * Track if button was clicked inside a dear imgui window or over void blocked by a popup. We don't request mouse capture from the application if click started outside ImGui bounds.
     */
    public void setMouseDownOwned(final int idx, final boolean value) {
        nSetMouseDownOwned(idx, value);
    }

    private native boolean[] nGetMouseDownOwned(); /*
        jboolean jBuf[5];
        for (int i = 0; i < 5; i++)
            jBuf[i] = THIS->MouseDownOwned[i];
        jbooleanArray result = env->NewBooleanArray(5);
        env->SetBooleanArrayRegion(result, 0, 5, jBuf);
        return result;
    */

    private native boolean nGetMouseDownOwned(int idx); /*
        return THIS->MouseDownOwned[idx];
    */

    private native void nSetMouseDownOwned(boolean[] value); /*
        for (int i = 0; i < 5; i++)
            THIS->MouseDownOwned[i] = value[i];
    */

    private native void nSetMouseDownOwned(int idx, boolean value); /*
        THIS->MouseDownOwned[idx] = value;
    */

    /**
     * Track if button was clicked inside a dear imgui window.
     */
    public boolean[] getMouseDownOwnedUnlessPopupClose() {
        return nGetMouseDownOwnedUnlessPopupClose();
    }

    /**
     * Track if button was clicked inside a dear imgui window.
     */
    public boolean getMouseDownOwnedUnlessPopupClose(final int idx) {
        return nGetMouseDownOwnedUnlessPopupClose(idx);
    }

    /**
     * Track if button was clicked inside a dear imgui window.
     */
    public void setMouseDownOwnedUnlessPopupClose(final boolean[] value) {
        nSetMouseDownOwnedUnlessPopupClose(value);
    }

    /**
     * Track if button was clicked inside a dear imgui window.
     */
    public void setMouseDownOwnedUnlessPopupClose(final int idx, final boolean value) {
        nSetMouseDownOwnedUnlessPopupClose(idx, value);
    }

    private native boolean[] nGetMouseDownOwnedUnlessPopupClose(); /*
        jboolean jBuf[5];
        for (int i = 0; i < 5; i++)
            jBuf[i] = THIS->MouseDownOwnedUnlessPopupClose[i];
        jbooleanArray result = env->NewBooleanArray(5);
        env->SetBooleanArrayRegion(result, 0, 5, jBuf);
        return result;
    */

    private native boolean nGetMouseDownOwnedUnlessPopupClose(int idx); /*
        return THIS->MouseDownOwnedUnlessPopupClose[idx];
    */

    private native void nSetMouseDownOwnedUnlessPopupClose(boolean[] value); /*
        for (int i = 0; i < 5; i++)
            THIS->MouseDownOwnedUnlessPopupClose[i] = value[i];
    */

    private native void nSetMouseDownOwnedUnlessPopupClose(int idx, boolean value); /*
        THIS->MouseDownOwnedUnlessPopupClose[idx] = value;
    */

    /**
     * On a non-Mac system, holding SHIFT requests WheelY to perform the equivalent of a WheelX event.
     * On a Mac system this is already enforced by the system.
     */
    public boolean getMouseWheelRequestAxisSwap() {
        return nGetMouseWheelRequestAxisSwap();
    }

    /**
     * On a non-Mac system, holding SHIFT requests WheelY to perform the equivalent of a WheelX event.
     * On a Mac system this is already enforced by the system.
     */
    public void setMouseWheelRequestAxisSwap(final boolean value) {
        nSetMouseWheelRequestAxisSwap(value);
    }

    private native boolean nGetMouseWheelRequestAxisSwap(); /*
        return THIS->MouseWheelRequestAxisSwap;
    */

    private native void nSetMouseWheelRequestAxisSwap(boolean value); /*
        THIS->MouseWheelRequestAxisSwap = value;
    */

    /**
     * (OSX) Set to true when the current click was a ctrl-click that spawned a simulated right click.
     */
    public boolean getMouseCtrlLeftAsRightClick() {
        return nGetMouseCtrlLeftAsRightClick();
    }

    /**
     * (OSX) Set to true when the current click was a ctrl-click that spawned a simulated right click.
     */
    public void setMouseCtrlLeftAsRightClick(final boolean value) {
        nSetMouseCtrlLeftAsRightClick(value);
    }

    private native boolean nGetMouseCtrlLeftAsRightClick(); /*
        return THIS->MouseCtrlLeftAsRightClick;
    */

    private native void nSetMouseCtrlLeftAsRightClick(boolean value); /*
        THIS->MouseCtrlLeftAsRightClick = value;
    */

    /**
     * Duration the mouse button has been down (0.0f == just clicked)
     */
    public float[] getMouseDownDuration() {
        return nGetMouseDownDuration();
    }

    /**
     * Duration the mouse button has been down (0.0f == just clicked)
     */
    public float getMouseDownDuration(final int idx) {
        return nGetMouseDownDuration(idx);
    }

    /**
     * Duration the mouse button has been down (0.0f == just clicked)
     */
    public void setMouseDownDuration(final float[] value) {
        nSetMouseDownDuration(value);
    }

    /**
     * Duration the mouse button has been down (0.0f == just clicked)
     */
    public void setMouseDownDuration(final int idx, final float value) {
        nSetMouseDownDuration(idx, value);
    }

    private native float[] nGetMouseDownDuration(); /*
        jfloat jBuf[5];
        for (int i = 0; i < 5; i++)
            jBuf[i] = THIS->MouseDownDuration[i];
        jfloatArray result = env->NewFloatArray(5);
        env->SetFloatArrayRegion(result, 0, 5, jBuf);
        return result;
    */

    private native float nGetMouseDownDuration(int idx); /*
        return THIS->MouseDownDuration[idx];
    */

    private native void nSetMouseDownDuration(float[] value); /*
        for (int i = 0; i < 5; i++)
            THIS->MouseDownDuration[i] = value[i];
    */

    private native void nSetMouseDownDuration(int idx, float value); /*
        THIS->MouseDownDuration[idx] = value;
    */

    /**
     * Previous time the mouse button has been down
     */
    public float[] getMouseDownDurationPrev() {
        return nGetMouseDownDurationPrev();
    }

    /**
     * Previous time the mouse button has been down
     */
    public float getMouseDownDurationPrev(final int idx) {
        return nGetMouseDownDurationPrev(idx);
    }

    /**
     * Previous time the mouse button has been down
     */
    public void setMouseDownDurationPrev(final float[] value) {
        nSetMouseDownDurationPrev(value);
    }

    /**
     * Previous time the mouse button has been down
     */
    public void setMouseDownDurationPrev(final int idx, final float value) {
        nSetMouseDownDurationPrev(idx, value);
    }

    private native float[] nGetMouseDownDurationPrev(); /*
        jfloat jBuf[5];
        for (int i = 0; i < 5; i++)
            jBuf[i] = THIS->MouseDownDurationPrev[i];
        jfloatArray result = env->NewFloatArray(5);
        env->SetFloatArrayRegion(result, 0, 5, jBuf);
        return result;
    */

    private native float nGetMouseDownDurationPrev(int idx); /*
        return THIS->MouseDownDurationPrev[idx];
    */

    private native void nSetMouseDownDurationPrev(float[] value); /*
        for (int i = 0; i < 5; i++)
            THIS->MouseDownDurationPrev[i] = value[i];
    */

    private native void nSetMouseDownDurationPrev(int idx, float value); /*
        THIS->MouseDownDurationPrev[idx] = value;
    */

    /**
     * Maximum distance, absolute, on each axis, of how much mouse has traveled from the clicking point
     */
    public ImVec2[] getMouseDragMaxDistanceAbs() {
        return nGetMouseDragMaxDistanceAbs();
    }

    /**
     * Maximum distance, absolute, on each axis, of how much mouse has traveled from the clicking point
     */
    public void setMouseDragMaxDistanceAbs(final ImVec2[] value) {
        nSetMouseDragMaxDistanceAbs(value);
    }

    private native ImVec2[] nGetMouseDragMaxDistanceAbs(); /*
        return Jni::NewImVec2Array(env, THIS->MouseDragMaxDistanceAbs, 5);
    */

    private native void nSetMouseDragMaxDistanceAbs(ImVec2[] value); /*
        Jni::ImVec2ArrayCpy(env, value, THIS->MouseDragMaxDistanceAbs, 5);
    */

    /**
     * Squared maximum distance of how much mouse has traveled from the clicking point
     */
    public float[] getMouseDragMaxDistanceSqr() {
        return nGetMouseDragMaxDistanceSqr();
    }

    /**
     * Squared maximum distance of how much mouse has traveled from the clicking point
     */
    public float getMouseDragMaxDistanceSqr(final int idx) {
        return nGetMouseDragMaxDistanceSqr(idx);
    }

    /**
     * Squared maximum distance of how much mouse has traveled from the clicking point
     */
    public void setMouseDragMaxDistanceSqr(final float[] value) {
        nSetMouseDragMaxDistanceSqr(value);
    }

    /**
     * Squared maximum distance of how much mouse has traveled from the clicking point
     */
    public void setMouseDragMaxDistanceSqr(final int idx, final float value) {
        nSetMouseDragMaxDistanceSqr(idx, value);
    }

    private native float[] nGetMouseDragMaxDistanceSqr(); /*
        jfloat jBuf[5];
        for (int i = 0; i < 5; i++)
            jBuf[i] = THIS->MouseDragMaxDistanceSqr[i];
        jfloatArray result = env->NewFloatArray(5);
        env->SetFloatArrayRegion(result, 0, 5, jBuf);
        return result;
    */

    private native float nGetMouseDragMaxDistanceSqr(int idx); /*
        return THIS->MouseDragMaxDistanceSqr[idx];
    */

    private native void nSetMouseDragMaxDistanceSqr(float[] value); /*
        for (int i = 0; i < 5; i++)
            THIS->MouseDragMaxDistanceSqr[i] = value[i];
    */

    private native void nSetMouseDragMaxDistanceSqr(int idx, float value); /*
        THIS->MouseDragMaxDistanceSqr[idx] = value;
    */

    /**
     * Touch/Pen pressure (0.0f to 1.0f, should be {@code >}0.0f only when MouseDown[0] == true). Helper storage currently unused by Dear ImGui.
     */
    public float getPenPressure() {
        return nGetPenPressure();
    }

    /**
     * Touch/Pen pressure (0.0f to 1.0f, should be {@code >}0.0f only when MouseDown[0] == true). Helper storage currently unused by Dear ImGui.
     */
    public void setPenPressure(final float value) {
        nSetPenPressure(value);
    }

    private native float nGetPenPressure(); /*
        return THIS->PenPressure;
    */

    private native void nSetPenPressure(float value); /*
        THIS->PenPressure = value;
    */

    /**
     * Only modify via AddFocusEvent().
     */
    public boolean getAppFocusLost() {
        return nGetAppFocusLost();
    }

    private native boolean nGetAppFocusLost(); /*
        return THIS->AppFocusLost;
    */

    /**
     * Only modify via SetAppAcceptingEvents().
     */
    public boolean getAppAcceptingEvents() {
        return nGetAppAcceptingEvents();
    }

    private native boolean nGetAppAcceptingEvents(); /*
        return THIS->AppAcceptingEvents;
    */

    // BackendUsingLegacyKeyArrays and BackendUsingLegacyNavInputArray were removed from ImGuiIO
    // in imgui 1.92 (the legacy code paths those fields gated are gone).

    /**
     * For AddInputCharacterUTF16
     */
    public short getInputQueueSurrogate() {
        return nGetInputQueueSurrogate();
    }

    /**
     * For AddInputCharacterUTF16
     */
    public void setInputQueueSurrogate(final short value) {
        nSetInputQueueSurrogate(value);
    }

    private native short nGetInputQueueSurrogate(); /*
        return THIS->InputQueueSurrogate;
    */

    private native void nSetInputQueueSurrogate(short value); /*
        THIS->InputQueueSurrogate = value;
    */

    // TODO: InputQueueCharacters

    /*JNI
        #undef THIS
     */
}
